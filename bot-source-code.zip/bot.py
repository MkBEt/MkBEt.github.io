#CodeiT Ethiopia
import logging'
from telegram import (ReplyKeyboardMarkup, ReplyKeyboardRemove)
from telegram.ext import (Updater, CommandHandler, MessageHandler, Filters,
                          ConversationHandler)

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)

logger = logging.getLogger(__name__)

IN= range(1)

def start(update, context):
	#server ላይ  History ለመመዝገብ
	logger.info("Mr of %s: start conversations", update.message.from_user.first_name)
	
	#Welcom message 
	context.bot.send_message(chat_id=update.message.chat_id, text="ሰላም " +update.message.from_user.first_name+ " Professor Bot እባላለሁ\n  How are you ?")
	
	return IN

#
def main_function(update,context):

	global text
	text = update.message.text

	#rep'y message of user send some text but text is not "/start""
	if text=! "/start"':
		update.message.reply_text("ይሄን በመስማቴ ደስ ብሎኛል ☺️ ")



#ተጨማር function 
def error(update, context):
    """Log Errors caused by Updates."""
    logger.warning('Update "%s" caused error "%s"', update, context.error)

def cancel(update, context):
    user = update.message.from_user
    logger.info("User %s canceled the conversation.", user.first_name)
    update.message.reply_text('Bye! I hope we can talk again some day.')

   

#Main function
def main():
   # የእርሶን  bot tokem ያስቀምጡ 
    updater = Updater("1082874895:AAF9egvWg7GdxBgV1MFdFkjVEu-w7IVJko", use_context=True)

    # Get the dispatcher to register handlers
    dp = updater.dispatcher

    # Add conversation handler with the states GENDER, PHOTO, LOCATION and BIO
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],

        states={
             IN: [MessageHandler(Filters.text , main_function)],
            
        },

       


        fallbacks=[CommandHandler('cancel', cancel)] ,)

    dp.add_handler(conv_handler)

    # log all errors
    dp.add_error_handler(error)

    # Start the Bot
    updater.start_polling()

    # Run the bot until you press Ctrl-C or the process receives SIGINT,
    # SIGTERM or SIGABRT. This should be used most of the time, since
    # start_polling() is non-blocking and will stop the bot gracefully.
    updater.idle()

print("the bot is started  ....)")
if __name__ == '__main__':
    main()
